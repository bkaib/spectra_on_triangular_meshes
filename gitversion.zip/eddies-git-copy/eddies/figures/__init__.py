import sys
sys.path.append('/home/ollie/kbelling/Python/eddy_diag/')