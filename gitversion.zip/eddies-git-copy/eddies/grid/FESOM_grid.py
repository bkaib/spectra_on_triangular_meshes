# Contains all variables used within the FESOM-Mesh
# Import standard python packages
# Sys
import sys
sys.path.append('/home/ollie/kbelling/pyfesom')
sys.path.append("/home/ollie/kbelling/pyfesom/pyfesom/")
sys.path.append("/home/h/hbkdsido/utils/seawater-1.1/")
                
# Data import
from netCDF4 import Dataset, MFDataset
                
# Data storage
import collections
import pandas as pd
                
# Math & Stats
import numpy as np
import math
import scipy as sc
import scipy.stats as stats
from scipy.io import netcdf
from scipy.interpolate import griddata
import random
                
# Plotting data
import matplotlib
import matplotlib.pylab as plt
import matplotlib.pyplot as plotter
from matplotlib.backends.backend_pdf import PdfPages
import colormap
import seawater as sw
from mpl_toolkits.basemap import Basemap

# FESOM Mesh
from load_mesh_data import *
from regriding import fesom2clim
from fesom_plot_tools import *

# Hack to fix missing PROJ4 env var
import os
import conda
conda_file_dir = conda.__file__
conda_dir = conda_file_dir.split('lib')[0]
proj_lib = os.path.join(os.path.join(conda_dir, 'share'), 'proj')
os.environ["PROJ_LIB"] = proj_lib

# Set the path to the mesh
meshpath  ='/work/ollie/sjuricke/Soufflet_20/'
alpha, beta, gamma=[0, 0, 0]

# load mesh
#print("mesh will be loaded")
mesh=load_mesh(meshpath, abg=[alpha, beta, gamma], usepickle = False)

# Upload mesh-variables
result_path='/work/ollie/sjuricke//outputSoufflet_20Leith/'

ncfile =result_path+'fesom.mesh.diag.nc'
str_id='nodes'
f = Dataset(ncfile, 'r', format='NETCDF4_CLASSIC')
#print (str(f.variables[str_id]))
nodes=f.variables[str_id]
nodes = np.squeeze(nodes)

ncfile =result_path+'fesom.mesh.diag.nc'
str_id='edges'
f = Dataset(ncfile, 'r', format='NETCDF4_CLASSIC')
#print (str(f.variables[str_id]))
edges=f.variables[str_id]
edges = np.squeeze(edges)-1

str_id='edge_tri'
f = Dataset(ncfile, 'r', format='NETCDF4_CLASSIC')
#print (str(f.variables[str_id]))
edge_tri=f.variables[str_id]
edge_tri = np.squeeze(edge_tri)-1

str_id='nlevels'
f = Dataset(ncfile, 'r', format='NETCDF4_CLASSIC')
#print (str(f.variables[str_id]))
nlevels=f.variables[str_id]
nlevels = np.squeeze(nlevels)-1

str_id='edge_cross_dxdy'
f = Dataset(ncfile, 'r', format='NETCDF4_CLASSIC')
#print (str(f.variables[str_id]))
edge_cross_dxdy=f.variables[str_id]
edge_cross_dxdy = np.squeeze(edge_cross_dxdy)

str_id='nod_area'
f = Dataset(ncfile, 'r', format='NETCDF4_CLASSIC')
#print (str(f.variables[str_id]))
nod_area=f.variables[str_id]
nod_area = np.squeeze(nod_area)

str_id='elem'
f = Dataset(ncfile, 'r', format='NETCDF4_CLASSIC')
#print (str(f.variables[str_id]))
elem=f.variables[str_id]
elem = np.squeeze(elem)-1

str_id='elem_area'
f = Dataset(ncfile, 'r', format='NETCDF4_CLASSIC')
#print (str(f.variables[str_id]))
elem_area=f.variables[str_id]
elem_area = np.squeeze(elem_area)

str_id='elem_n'
f = Dataset(ncfile, 'r', format='NETCDF4_CLASSIC')
#print (str(f.dimensions[str_id]))
elem_n=len(f.dimensions[str_id])

str_id='nod_n'
f = Dataset(ncfile, 'r', format='NETCDF4_CLASSIC')
#print (str(f.dimensions[str_id]))
nod_n=len(f.dimensions[str_id])

str_id='edg_n'
f = Dataset(ncfile, 'r', format='NETCDF4_CLASSIC')
#print (str(f.dimensions[str_id]))
edg_n=len(f.dimensions[str_id])

str_id='nl'
f = Dataset(ncfile, 'r', format='NETCDF4_CLASSIC')
#print (str(f.dimensions[str_id]))
nl=len(f.dimensions[str_id])

# calculate coordinates
xx2=np.zeros(shape=(elem_n))
yy2=np.zeros(shape=(elem_n))
for i in np.arange(0,elem_n):
    xx2[i]=mesh.x2[mesh.elem[i,:]].mean(axis=0)
    yy2[i]=mesh.y2[mesh.elem[i,:]].mean(axis=0)
    
# Create coordinates of centroids
aa = np.shape(elem)
elem_x = np.zeros(aa[1])
elem_y = np.zeros(aa[1])

for el in np.arange(0,aa[1],1):
    elem_x[el]=np.mean(mesh.x2[elem[:,el]])
    elem_y[el]=np.mean(mesh.y2[elem[:,el]])
    
################################################ Own modules #######################

# Parameters
left_boundary = np.arange(0, 228, 2)
right_boundary = np.arange(5473, 5701, 2)

def elem_neighbours():
    """
    DOC:
        Returns all centroid-neighbours c' of a centroid c. Neighbouring centroids share a
        common edge, i.e. two same nodes within the grid. 
        This function has no boundary conditions, i.e. includes triangles c' wrapping
        around the channel as neighbours of c.
    RETURN: 
        elem_neighbours, type:np.array, shape:(3,elem_n), Each centroid c contains of
        maximal 3 neighbours c'.
    """
    el = elem # Nodes of centroids
    el_n = elem_n
    elem_neighbours = np.zeros(shape=(3,el_n))
    
    for c in range(el_n):
        # Initialize
        nodes_c = el[:,c] # Nodes of specific centroid
        
        # Sets with same nodes as cell c
        A = np.where(el == nodes_c[0])[1] 
        B = np.where(el == nodes_c[1])[1]
        C = np.where(el == nodes_c[2])[1]
        
        # Intersection gives neighbouring cells c' of c, 
        # Setdiff subtracts c of this s
        n1 = np.setdiff1d(np.intersect1d(A,B), c)
        n2 = np.setdiff1d(np.intersect1d(A,C), c)
        n3 = np.setdiff1d(np.intersect1d(B,C), c)
        
        # Put all neighbour cells c' in one set
        neighbours = np.union1d(np.union1d(n1,n2), n3)
        neighbours = neighbours.astype('float')
        
        # Save neighbours to shape=(3,) array for saving to elem_neighbours
        neighbour = np.zeros(shape=3, dtype='float')
        neighbour[:] = np.nan
        index = 0
        for n in neighbours:
            neighbour[index] = n
            index = index + 1
        
        elem_neighbours[:, c] = neighbour
    
    return elem_neighbours   

def elem_neighbours_bc():
    """
    DOC: 
        Returns all centroid-neighbours c' of a centroid c. Neighbouring centroids share a
        common edge, i.e. two same nodes within the grid. 
        This function includes boundary conditions, i.e. excludes triangles c' wrapping
        around the channel as neighbours of c.
    RETURN: 
        elem_neighbours, type:np.array, shape:(3,elem_n), Each centroid c contains of
        maximal 3 neighbours c'.
    """
    el = elem # Nodes of centroids
    el_n = elem_n
    elem_neighbours = np.zeros(shape=(3,el_n))
    
    for c in range(el_n):
        # Initialize
        nodes_c = el[:,c] # Nodes of specific centroid
        
        # Sets with same nodes as cell c
        A = np.where(el == nodes_c[0])[1] 
        B = np.where(el == nodes_c[1])[1]
        C = np.where(el == nodes_c[2])[1]
        
        # Intersection gives neighbouring cells c' of c, 
        # Setdiff subtracts c of this s
        n1 = np.setdiff1d(np.intersect1d(A,B), c)
        n2 = np.setdiff1d(np.intersect1d(A,C), c)
        n3 = np.setdiff1d(np.intersect1d(B,C), c)
        
        # Put all neighbour cells c' in one set
        neighbours = np.union1d(np.union1d(n1,n2), n3)
        neighbours = neighbours.astype('float')
        
        # Left boundary
        if c in left_boundary:
            index = 0
            for n in neighbours:
                if n in right_boundary:
                    neighbours[index] = np.nan # If a neighbour wraps around, set to NaN
                index = index + 1
        # Right boundary        
        if c in right_boundary:
            index = 0
            for n in neighbours:
                if n in left_boundary:
                    neighbours[index] = np.nan
                index = index + 1
        
        # Save neighbours to shape=(3,) array for saving to elem_neighbours
        neighbour = np.zeros(shape=3, dtype='float')
        neighbour[:] = np.nan
        index = 0
        for n in neighbours:
            neighbour[index] = n
            index = index + 1
        
        elem_neighbours[:, c] = neighbour
    
    return elem_neighbours