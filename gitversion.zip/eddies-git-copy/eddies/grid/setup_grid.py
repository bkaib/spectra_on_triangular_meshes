def regular_grid(lx, ly, dx, dy, sx, sy):
    """
    Description: Creates a regular grid.
    
    Input:
    lx, ly: length in zonal and meridional direction
    dx, dy: stepsize in zonal and meridional direction
    sx, sy: starting values zonal and meridional direction 
    
    Output:
    Coordinates of a regular grid in meshgrid format
    """
    import numpy as np
    
    xx = np.arange(sx, lx, dx) # Coordinates of regular grid
    yy = np.arange(sy, ly, dy)
    
    XX, YY = np.meshgrid(xx, yy) # Grid
    
    return (XX, YY)