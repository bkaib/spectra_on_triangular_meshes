import matplotlib.pylab as plt
import numpy as np

def run():
    print('Diagnostics still have to be implemented')