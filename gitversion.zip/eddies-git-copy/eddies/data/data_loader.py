#----------------------
# Import modules for this package
#----------------------

def load_original_data(path, year, model_run):
    """
    year: str(), 
    path: str(), must end with '/'.
    
    Output: u, udis, v, vdis
    """
    from netCDF4 import Dataset
    
#     model_run = input('What scheme (GAMB, EASY4)?')
#     model_run = model_run.lower()
    
    if model_run == 'easy4':
        str_id = 'u'
        ncfile = path + str_id + '.fesom.' + year + '.nc'
        f = Dataset(ncfile, 'r', format='NETCDF4_CLASSIC')
        data2 = f.variables[str_id]
    
        u = data2[:,:,:].squeeze()
    
        str_id = 'u_dis_tend'
        ncfile = path + str_id + '.fesom.' + year + '.nc'
        f = Dataset(ncfile, 'r', format='NETCDF4_CLASSIC')
        data2 = f.variables[str_id]
    
        udis = data2[:,:,:].squeeze()
    
        str_id = 'v'
        ncfile = path + str_id + '.fesom.' + year + '.nc'
        f = Dataset(ncfile, 'r', format='NETCDF4_CLASSIC')
        data2 = f.variables[str_id]
    
        v = data2[:,:,:].squeeze()
    
        str_id = 'v_dis_tend'
        ncfile = path + str_id + '.fesom.' + year + '.nc'
        f = Dataset(ncfile, 'r', format='NETCDF4_CLASSIC')
        data2 = f.variables[str_id]
    
        vdis = data2[:,:,:].squeeze()
    elif model_run == 'gamb':
        str_id = 'u'
        ncfile = path + str_id + '.fesom.' + year + '.nc'
        f = Dataset(ncfile, 'r', format='NETCDF4_CLASSIC')
        data2 = f.variables[str_id]
        
        u = data2[:,:,:].squeeze()
        
        str_id = 'u_total_tend'
        ncfile = path + str_id + '.fesom.' + year + '.nc'
        f = Dataset(ncfile, 'r', format='NETCDF4_CLASSIC')
        data2 = f.variables[str_id]
        
        udis = data2[:,:,:].squeeze()
        
        str_id = 'v'
        ncfile = path + str_id + '.fesom.' + year + '.nc'
        f = Dataset(ncfile, 'r', format='NETCDF4_CLASSIC')
        data2 = f.variables[str_id]
        
        v = data2[:,:,:].squeeze()
        
        str_id = 'v_total_tend'
        ncfile = path + str_id + '.fesom.' + year + '.nc'
        f = Dataset(ncfile, 'r', format='NETCDF4_CLASSIC')
        data2 = f.variables[str_id]
        
        vdis = data2[:,:,:].squeeze()
        
    else:
        return None
    
    return (u, udis, v, vdis)

def load_interpolated_total_energetics(f_dis, f_ke, filled=True):
    """
    Description: 
    Load total energetics of interpolated data for each method and returns it in one array
    
    Input:
    f_dis, f_ke, description of the file, type:str
    filled, whether NaN-values of interpolated data was filled at the boarder or not, type:boolean
    
    Output:
    dis_interp, ke_interp, total energetics of dissipation or kinetic energy of interpolated data, shape=(methods,)
    """
    #- Modules
    import numpy as np
    
    #- Exceptions
    assert type(f_dis) == str, 'Need a string as input'
    assert type(f_ke) == str, 'Need a string as input'
    
    #- Parameters
    folder     = '../resources/total_energetics_interpolated/'
    methods    = ['nearest', 'linear', 'cubic']
    
    #- Ratios for different starting values
    ke_interp  = np.zeros(len(methods)) 
    dis_interp = np.zeros(len(methods))
    
    #- Load all energetics for grid spacings
    for i, method in enumerate(methods):
        if filled == True:
            #- Grid of certain gridspacing
            ke_interp[i]  = np.load(folder + f_ke +  '_' + method  + '_' + 'filled_boarders.npy')
            dis_interp[i] = np.load(folder + f_dis +  '_' + method + '_' + 'filled_boarders.npy')       
        else:
            #- Grid of certain gridspacing
            ke_interp[i]  = np.load(folder + f_ke +  '_' + method  + '.npy')
            dis_interp[i] = np.load(folder + f_dis +  '_' + method + '.npy')
        
    return dis_interp, ke_interp